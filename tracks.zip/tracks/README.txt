
As of February 2024 this assignment is done using a CSV file

The tracks.py program reads the tracks.csv file and inserts
the data into an SQLite database with many-to-one relationships.

